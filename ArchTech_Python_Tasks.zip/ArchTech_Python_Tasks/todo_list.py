import json
import os

FILE_NAME = "todo_data.json"

def load_tasks():
    """Loads tasks from file if available."""
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, "r") as f:
            return json.load(f)
    return []

def save_tasks(tasks):
    """Saves tasks to file."""
    with open(FILE_NAME, "w") as f:
        json.dump(tasks, f, indent=4)

def view_tasks(tasks, show_completed=False, category=None):
    """Displays tasks (filtered by completion or category)."""
    print("\n📋 Your Tasks:")
    for i, task in enumerate(tasks, start=1):
        if (show_completed and task['completed']) or (not show_completed and not task['completed']):
            if category is None or task['category'].lower() == category.lower():
                status = "✅" if task['completed'] else "❌"
                print(f"{i}. [{status}] {task['title']} ({task['category']})")

def add_task(tasks):
    title = input("Enter task description: ")
    category = input("Enter category (Work/Personal/etc): ")
    tasks.append({"title": title, "category": category, "completed": False})
    save_tasks(tasks)
    print("Task added!")

def mark_task_completed(tasks):
    view_tasks(tasks, show_completed=False)
    try:
        task_num = int(input("Enter task number to mark as completed: "))
        tasks[task_num - 1]["completed"] = True
        save_tasks(tasks)
        print("Task marked as completed!")
    except (ValueError, IndexError):
        print("Invalid task number!")

def remove_task(tasks):
    view_tasks(tasks)
    try:
        task_num = int(input("Enter task number to remove: "))
        tasks.pop(task_num - 1)
        save_tasks(tasks)
        print("Task removed!")
    except (ValueError, IndexError):
        print("Invalid task number!")

def main():
    tasks = load_tasks()

    while True:
        print("\n=== TO-DO LIST MENU ===")
        print("1. View pending tasks")
        print("2. View completed tasks")
        print("3. View tasks by category")
        print("4. Add a task")
        print("5. Mark a task as completed")
        print("6. Remove a task")
        print("7. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            view_tasks(tasks, show_completed=False)
        elif choice == "2":
            view_tasks(tasks, show_completed=True)
        elif choice == "3":
            cat = input("Enter category to filter: ")
            view_tasks(tasks, category=cat)
        elif choice == "4":
            add_task(tasks)
        elif choice == "5":
            mark_task_completed(tasks)
        elif choice == "6":
            remove_task(tasks)
        elif choice == "7":
            print("Goodbye 👋")
            break
        else:
            print("Invalid choice. Try again!")

if __name__ == "__main__":
    main()
