import random

def roll_dice(num_dice):
    """Rolls the given number of dice and returns the results as a list."""
    return [random.randint(1, 6) for _ in range(num_dice)]

def main():
    roll_count = 0  # Counter to track rolls

    print("🎲 Welcome to the Dice Rolling Game!")

    while True:
        try:
            num_dice = int(input("\nHow many dice would you like to roll? "))
        except ValueError:
            print("Please enter a valid number!")
            continue

        results = roll_dice(num_dice)
        roll_count += 1

        print(f"You rolled: {results}")
        print(f"Total rolls this session: {roll_count}")

        again = input("Do you want to roll again? (y/n): ").strip().lower()
        if again != 'y':
            print("Thanks for playing! Goodbye 👋")
            break

if __name__ == "__main__":
    main()
