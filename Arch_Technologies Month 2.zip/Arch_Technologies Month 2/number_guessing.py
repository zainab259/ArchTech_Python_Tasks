import random

def play_game():
    print("🎯 Welcome to the Number Guessing Game!")

    # User defines range
    try:
        min_val = int(input("Enter minimum number: "))
        max_val = int(input("Enter maximum number: "))
        if min_val >= max_val:
            print("Minimum must be less than maximum. Using default 1–100.")
            min_val, max_val = 1, 100
    except ValueError:
        print("Invalid input. Using default range 1–100.")
        min_val, max_val = 1, 100

    # Computer picks a number
    number = random.randint(min_val, max_val)

    # Set guess limit (logarithmic for fair difficulty)
    attempts_allowed = int((max_val - min_val) ** 0.5) + 5
    print(f"\nYou have {attempts_allowed} attempts to guess the number!")

    attempts = 0
    best_score = None

    while attempts < attempts_allowed:
        try:
            guess = int(input("Enter your guess: "))
        except ValueError:
            print("Please enter a valid number.")
            continue

        attempts += 1

        if guess == number:
            print(f"🎉 Correct! You guessed it in {attempts} attempts.")
            if best_score is None or attempts < best_score:
                best_score = attempts
            break
        elif guess < number:
            print("Too low! Try again.")
        else:
            print("Too high! Try again.")

        print(f"Attempts left: {attempts_allowed - attempts}")

    else:  # If loop finishes without break
        print(f"😢 Out of attempts! The number was {number}.")

    print("\n=== GAME OVER ===")
    if best_score:
        print(f"🏆 Best score (fewest attempts): {best_score}")

def main():
    while True:
        play_game()
        again = input("\nDo you want to play again? (y/n): ").lower()
        if again != "y":
            print("Thanks for playing! 👋")
            break

if __name__ == "__main__":
    main()
