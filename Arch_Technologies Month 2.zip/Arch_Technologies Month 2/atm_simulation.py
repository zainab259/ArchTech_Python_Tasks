class ATM:
    def __init__(self, balance=0):
        self.balance = balance

    def check_balance(self):
        return f"Your balance is: ${self.balance:.2f}"

    def deposit(self, amount):
        if amount <= 0:
            return "Deposit amount must be greater than 0."
        self.balance += amount
        return f"${amount:.2f} deposited successfully! New balance: ${self.balance:.2f}"

    def withdraw(self, amount):
        if amount <= 0:
            return "Withdrawal amount must be greater than 0."
        if amount > self.balance:
            return "Insufficient funds!"
        self.balance -= amount
        return f"${amount:.2f} withdrawn successfully! New balance: ${self.balance:.2f}"


class ATMController:
    def __init__(self):
        self.atm = ATM(balance=1000)  # start with $1000 for demo

    def run(self):
        while True:
            print("\n=== ATM MENU ===")
            print("1. Check Balance")
            print("2. Deposit Money")
            print("3. Withdraw Money")
            print("4. Exit")

            choice = input("Enter your choice: ")

            if choice == "1":
                print(self.atm.check_balance())
            elif choice == "2":
                try:
                    amount = float(input("Enter deposit amount: "))
                    print(self.atm.deposit(amount))
                except ValueError:
                    print("Invalid input. Please enter a number.")
            elif choice == "3":
                try:
                    amount = float(input("Enter withdrawal amount: "))
                    print(self.atm.withdraw(amount))
                except ValueError:
                    print("Invalid input. Please enter a number.")
            elif choice == "4":
                print("Thank you for using the ATM. Goodbye 👋")
                break
            else:
                print("Invalid choice. Try again!")


if __name__ == "__main__":
    controller = ATMController()
    controller.run()
